<?php
require_once __DIR__ . '/vendor/autoload.php';

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'primefix_db';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Brand extraction and linking started...\n";

    // Common printer brands to look for
    $knownBrands = ['HP', 'Canon', 'Brother', 'Epson', 'Samsung', 'Xerox', 'Lexmark', 'Kyocera', 'Ricoh', 'OKI', 'Pantun', 'Fujifilm', 'Dell', 'Konica Minolta'];

    // Fetch products that don't have a brand_id yet or have 0
    $stmt = $pdo->query("SELECT id, name FROM products WHERE brand_id IS NULL OR brand_id = 0");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $brandCache = [];
    $updatedCount = 0;

    foreach ($products as $p) {
        $foundBrand = null;
        
        foreach ($knownBrands as $kb) {
            // Case-insensitive search for the brand name in the product name
            if (stripos($p['name'], $kb) !== false) {
                $foundBrand = $kb;
                break;
            }
        }

        if ($foundBrand) {
            // Ensure brand exists in the brands table
            if (!isset($brandCache[$foundBrand])) {
                $stmt = $pdo->prepare("SELECT id FROM brands WHERE name = ? LIMIT 1");
                $stmt->execute([$foundBrand]);
                $brand = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($brand) {
                    $brandCache[$foundBrand] = $brand['id'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO brands (name, status) VALUES (?, 'published')");
                    $stmt->execute([$foundBrand]);
                    $brandCache[$foundBrand] = $pdo->lastInsertId();
                    echo "Created new brand: $foundBrand\n";
                }
            }

            // Update product with brand_id
            $stmt = $pdo->prepare("UPDATE products SET brand_id = ? WHERE id = ?");
            $stmt->execute([$brandCache[$foundBrand], $p['id']]);
            $updatedCount++;
        }
    }

    echo "\nFinished! Updated $updatedCount products with their respective brands.\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}