<?php
$p=new PDO('mysql:host=localhost;dbname=primefix_db','root','');
foreach($p->query('SELECT id, name, parent_id FROM categories') as $r) {
    echo "ID: {$r['id']} | Name: {$r['name']} | Parent: {$r['parent_id']}
";
}
