<?php
$p=new PDO('mysql:host=localhost;dbname=primefix_db','root','');
echo "New Products (Migrated):
";
foreach($p->query('SELECT images FROM products ORDER BY id DESC LIMIT 3') as $r) {
    echo $r['images'] . "
";
}
echo "
Old Products (Existing):
";
foreach($p->query('SELECT images FROM products ORDER BY id ASC LIMIT 3') as $r) {
    echo $r['images'] . "
";
}
