<?php
require_once __DIR__ . '/vendor/autoload.php';

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'primefix_db';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Updating image paths...
";

    // Update products where images JSON doesn't contain 'products/'
    // This targets only the newly migrated ones
    $stmt = $pdo->query("SELECT id, images FROM products WHERE images NOT LIKE '%products/%'");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $count = 0;
    foreach ($products as $p) {
        $images = json_decode($p['images'], true);
        if (is_array($images)) {
            $updatedImages = array_map(function($img) {
                // Only prepend if not already present
                if (strpos($img, 'products/') !== 0) {
                    return 'products/' . $img;
                }
                return $img;
            }, $images);

            $stmtUpdate = $pdo->prepare("UPDATE products SET images = ? WHERE id = ?");
            $stmtUpdate->execute([json_encode($updatedImages), $p['id']]);
            $count++;
        }
    }

    echo "Finished! Updated $count product image paths.
";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "
";
}
