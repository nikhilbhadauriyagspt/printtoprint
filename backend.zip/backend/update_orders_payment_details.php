<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

try {
    $db = (new Database())->getConnection();
    $db->exec("ALTER TABLE orders ADD COLUMN payment_details JSON NULL AFTER payment_method");
    echo "Added payment_details column successfully!
";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "
";
}
