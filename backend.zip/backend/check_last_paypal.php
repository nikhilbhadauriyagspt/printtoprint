<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

try {
    $db = (new Database())->getConnection();
    $stmt = $db->query("SELECT id, payment_method, payment_details FROM orders WHERE payment_method = 'paypal' ORDER BY created_at DESC LIMIT 1");
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order) {
        echo "Order ID: #PFX-{$order['id']}
";
        echo "Method: {$order['payment_method']}
";
        echo "Details: " . ($order['payment_details'] ?: 'NULL') . "
";
    } else {
        echo "No PayPal orders found.
";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "
";
}
