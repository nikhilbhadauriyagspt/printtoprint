<?php
$p=new PDO('mysql:host=localhost;dbname=primefix_db','root','');
foreach($p->query('SELECT name, logo FROM brands') as $r) {
    echo "Name: {$r['name']} | Logo: {$r['logo']}
";
}
