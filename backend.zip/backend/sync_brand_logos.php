<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'primefix_db';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Mapping based on files found in public/brands
    $mapping = [
        'Acer' => 'brands/acer-logo.png',
        'Asus' => 'brands/asus.logo.jpg',
        'Brother' => 'brands/brother-logo.jpg',
        'Canon' => 'brands/canon.png',
        'Dell' => 'brands/dell.webp',
        'Epson' => 'brands/espon.png', // Note: your file is 'espon.png'
        'HP' => 'brands/hp.jpg',
        'Lenovo' => 'brands/lenovo.webp',
        'Lexmark' => 'brands/Lexmark.png',
        'Xerox' => 'brands/xerox.png'
    ];

    foreach ($mapping as $name => $path) {
        $stmt = $pdo->prepare("UPDATE brands SET logo = ? WHERE name = ?");
        $stmt->execute([$path, $name]);
        if ($stmt->rowCount() > 0) {
            echo "Updated '$name' with logo: '$path'
";
        } else {
            echo "No change for '$name' (maybe already set or name mismatch)
";
        }
    }

    echo "
Finished updating brand logos.
";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "
";
}
