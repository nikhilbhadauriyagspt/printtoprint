<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

$db = (new Database())->getConnection();
$stmt = $db->query("SELECT id, name, slug FROM categories");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($categories as $cat) {
    echo "ID: {$cat['id']} | Name: {$cat['name']} | Slug: {$cat['slug']}
";
}
