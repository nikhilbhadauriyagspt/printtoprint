<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;
use App\Controllers\AuthController;
use App\Controllers\ProductController;
use App\Controllers\DashboardController;
use App\Controllers\CategoryController;
use App\Controllers\BrandController;
use App\Controllers\UserController;
use App\Controllers\OrderController;
use App\Controllers\ContactController;
use App\Controllers\NewsletterController;

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->safeLoad();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// Auth Routes
if ($uri === '/login' && $method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $auth = new AuthController();
    echo json_encode($auth->login($data));
    exit;
}

if ($uri === '/register' && $method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $auth = new AuthController();
    echo json_encode($auth->register($data));
    exit;
}

// Dashboard Routes
if ($uri === '/admin/stats' && $method === 'GET') {
    $dashboard = new DashboardController();
    echo json_encode($dashboard->stats());
    exit;
}

// Category Routes
if (strpos($uri, '/categories') === 0) {
    $catController = new CategoryController();
    if ($method === 'GET') { echo json_encode($catController->index()); exit; }
    if ($method === 'POST') { 
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($catController->store($data)); 
        exit; 
    }
    if ($method === 'DELETE') {
        preg_match('/\/categories\/(\d+)/', $uri, $matches);
        echo json_encode($catController->delete($matches[1] ?? 0));
        exit;
    }
}

// Brand Routes
if (strpos($uri, '/brands') === 0) {
    $brandController = new BrandController();
    if ($method === 'GET') { echo json_encode($brandController->index()); exit; }
    if ($method === 'POST') { 
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($brandController->store($data)); 
        exit; 
    }
    if ($method === 'DELETE') {
        preg_match('/\/brands\/(\d+)/', $uri, $matches);
        echo json_encode($brandController->delete($matches[1] ?? 0));
        exit;
    }
}

// User Routes
if (strpos($uri, '/users') === 0) {
    $userController = new UserController();
    if ($method === 'GET') { echo json_encode($userController->index()); exit; }
    if ($method === 'PUT') {
        preg_match('/\/users\/(\d+)/', $uri, $matches);
        $id = $matches[1] ?? null;
        if ($id) {
            $data = json_decode(file_get_contents("php://input"), true);
            echo json_encode($userController->update($id, $data));
            exit;
        }
    }
    if ($method === 'DELETE') {
        preg_match('/\/users\/(\d+)/', $uri, $matches);
        echo json_encode($userController->delete($matches[1] ?? 0));
        exit;
    }
}

// Product Routes
if (strpos($uri, '/products') === 0) {
    $productController = new ProductController();
    
    // GET /products
    if ($method === 'GET') {
        preg_match('/\/products\/(\d+)/', $uri, $matches);
        $id = $matches[1] ?? null;
        if ($id) {
            echo json_encode($productController->show($id));
            exit;
        }
        echo json_encode($productController->index($_GET));
        exit;
    }
    
    // POST /products
    if ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($productController->store($data));
        exit;
    }

    // PUT /products/{id}
    if ($method === 'PUT') {
        preg_match('/\/products\/(\d+)/', $uri, $matches);
        $id = $matches[1] ?? null;
        if ($id) {
            $data = json_decode(file_get_contents("php://input"), true);
            echo json_encode($productController->update($id, $data));
            exit;
        }
    }

    // DELETE /products/{id}
    if ($method === 'DELETE') {
        preg_match('/\/products\/(\d+)/', $uri, $matches);
        $id = $matches[1] ?? null;
        if ($id) {
            echo json_encode($productController->delete($id));
            exit;
        }
    }
}

// Order Routes
if (strpos($uri, '/orders') === 0) {
    $orderController = new OrderController();
    
    // Admin specific routes
    if ($uri === '/orders/all' && $method === 'GET') {
        echo json_encode($orderController->all());
        exit;
    }

    if (preg_match('/\/orders\/(\d+)\/status/', $uri, $matches) && $method === 'PUT') {
        $id = $matches[1];
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($orderController->updateStatus($id, $data['status']));
        exit;
    }

    if ($method === 'GET') {
        echo json_encode($orderController->index($_GET));
        exit;
    }
    if ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($orderController->store($data));
        exit;
    }
}

// Contact Routes
if (strpos($uri, '/contacts') === 0) {
    $contactController = new ContactController();
    if ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($contactController->store($data));
        exit;
    }
    if ($method === 'GET') {
        echo json_encode($contactController->index());
        exit;
    }
    if (preg_match('/\/contacts\/(\d+)\/status/', $uri, $matches) && $method === 'PUT') {
        $id = $matches[1];
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($contactController->updateStatus($id, $data['status']));
        exit;
    }
}

// Newsletter Routes
if (strpos($uri, '/newsletter') === 0) {
    $newsletterController = new NewsletterController();
    if ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        echo json_encode($newsletterController->subscribe($data));
        exit;
    }
    if ($method === 'GET') {
        echo json_encode($newsletterController->index());
        exit;
    }
}

// Default response
echo json_encode([
    "status" => "success",
    "message" => "PrimeFix API is running",
    "endpoints" => [
        "POST /login" => "Requires {type, identifier, password}"
    ]
]);