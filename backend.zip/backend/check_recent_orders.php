<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

try {
    $db = (new Database())->getConnection();
    $stmt = $db->query("SELECT id, first_name, total_amount, payment_method, status, created_at FROM orders ORDER BY created_at DESC LIMIT 5");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "No orders found in the database.
";
    } else {
        echo "Recent Orders:
";
        foreach ($orders as $order) {
            echo "ID: #PFX-{$order['id']} | Customer: {$order['first_name']} | Amount: \${$order['total_amount']} | Method: {$order['payment_method']} | Status: {$order['status']} | Date: {$order['created_at']}
";
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "
";
}
