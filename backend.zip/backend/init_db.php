<?php
require_once __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;
use App\Config\Database;

// Load env but allow missing for initial setup if needed
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$dbName = $_ENV['DB_NAME'] ?? 'primefix_db';

try {
    // Connect without DB first to create it
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Creating database if not exists...
";
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbName");
    $pdo->exec("USE $dbName");
    
    echo "Creating tables...
";
    $sql = file_get_contents(__DIR__ . '/db/schema.sql');
    // Remove the database creation lines from schema if they exist to avoid conflict
    $sql = preg_replace('/CREATE DATABASE IF NOT EXISTS.*;/i', '', $sql);
    $sql = preg_replace('/USE .*/i', '', $sql);
    
    $pdo->exec($sql);
    echo "Database initialization successful!
";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "
";
    exit(1);
}
