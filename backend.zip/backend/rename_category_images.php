<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'primefix_db';
$dir = __DIR__ . '/../public/category/';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Scanning directory: $dir
";
    $files = array_diff(scandir($dir), array('..', '.'));

    // Mapping patterns to category names
    $mapping = [
        'inkjet' => 'Inkjet Printers',
        'laser' => 'Laser Printers',
        'supertank' => 'Supertank Printers',
        'led' => 'LED Printers',
        'thermal' => 'Thermal Printers',
        'photo' => 'Photo Printers',
        'dot matrix' => 'Dot Matrix Printers',
        'all-in-one' => 'All-In-One Printers',
        'windows laptop' => 'PC Laptops',
        '2-in-1' => '2-In-1 Laptops',
        'chromebook' => 'Chromebooks',
        'accessories' => 'Printer Accessories',
        'large format' => 'Large Format Printers'
    ];

    foreach ($files as $file) {
        $oldPath = $dir . $file;
        $found = false;

        foreach ($mapping as $key => $catName) {
            if (stripos($file, $key) !== false) {
                $extension = pathinfo($file, PATHINFO_EXTENSION);
                $newName = str_replace(' ', '-', strtolower($catName)) . '.' . $extension;
                $newPath = $dir . $newName;

                if (rename($oldPath, $newPath)) {
                    echo "Renamed: '$file' -> '$newName'
";
                    
                    // Update Database
                    $stmt = $pdo->prepare("UPDATE categories SET image = ? WHERE name = ?");
                    $dbPath = 'category/' . $newName;
                    $stmt->execute([$dbPath, $catName]);
                    echo "Updated DB for '$catName' with path: '$dbPath'
";
                }
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            echo "No match found for: $file
";
        }
    }

    echo "
Finished renaming and updating database.
";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "
";
}
