<?php
require 'vendor/autoload.php';
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$targetDB = $_ENV['DB_NAME'] ?? 'primefix_db';
$sourceDB = 'prime_fix_new';

try {
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "--- Starting Migration from $sourceDB to $targetDB ---
";

    // 1. Initialize Target Schema
    echo "Creating tables in $targetDB...
";
    $sql = file_get_contents(__DIR__ . '/db/ecommerce_schema.sql');
    $pdo->exec($sql);

    // 2. Migrate Brands
    echo "Migrating Brands...
";
    $stmt = $pdo->query("SELECT * FROM $sourceDB.ec_brands");
    $brands = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $insertBrand = $pdo->prepare("INSERT IGNORE INTO $targetDB.brands (id, name, logo, website, status, `order_column`, created_at) VALUES (:id, :name, :logo, :website, :status, :order, :created_at)");
    
    foreach ($brands as $b) {
        $insertBrand->execute([
            ':id' => $b['id'],
            ':name' => $b['name'],
            ':logo' => $b['logo'],
            ':website' => $b['website'],
            ':status' => $b['status'],
            ':order' => $b['order'],
            ':created_at' => $b['created_at']
        ]);
    }
    echo "Brands migrated: " . count($brands) . "
";

    // 3. Migrate Categories
    echo "Migrating Categories...
";
    $stmt = $pdo->query("SELECT * FROM $sourceDB.ec_product_categories");
    $cats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $insertCat = $pdo->prepare("INSERT IGNORE INTO $targetDB.categories (id, name, slug, parent_id, description, image, icon, status, `order_column`, is_featured, created_at) VALUES (:id, :name, :slug, :parent_id, :description, :image, :icon, :status, :order, :is_featured, :created_at)");

    foreach ($cats as $c) {
        $insertCat->execute([
            ':id' => $c['id'],
            ':name' => $c['name'],
            ':slug' => $c['slug'],
            ':parent_id' => $c['parent_id'],
            ':description' => $c['description'],
            ':image' => $c['image'],
            ':icon' => $c['icon'],
            ':status' => $c['status'],
            ':order' => $c['order'],
            ':is_featured' => $c['is_featured'],
            ':created_at' => $c['created_at']
        ]);
    }
    echo "Categories migrated: " . count($cats) . "
";

    // 4. Migrate Products
    echo "Migrating Products...
";
    $stmt = $pdo->query("SELECT * FROM $sourceDB.ec_products");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $insertProduct = $pdo->prepare("INSERT IGNORE INTO $targetDB.products (id, name, slug, description, content, status, images, sku, quantity, price, sale_price, is_featured, brand_id, views, created_at) VALUES (:id, :name, :slug, :description, :content, :status, :images, :sku, :quantity, :price, :sale_price, :is_featured, :brand_id, :views, :created_at)");

    foreach ($products as $p) {
        $insertProduct->execute([
            ':id' => $p['id'],
            ':name' => $p['name'],
            ':slug' => $p['slug'],
            ':description' => $p['description'],
            ':content' => $p['content'],
            ':status' => $p['status'],
            ':images' => $p['images'],
            ':sku' => $p['sku'],
            ':quantity' => $p['quantity'],
            ':price' => $p['price'],
            ':sale_price' => $p['sale_price'],
            ':is_featured' => $p['is_featured'],
            ':brand_id' => $p['brand_id'],
            ':views' => $p['views'],
            ':created_at' => $p['created_at']
        ]);
    }
    echo "Products migrated: " . count($products) . "
";

    // 5. Migrate Pivot
    echo "Linking Products to Categories...
";
    $stmt = $pdo->query("SELECT * FROM $sourceDB.ec_product_category_product");
    $pivots = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $insertPivot = $pdo->prepare("INSERT IGNORE INTO $targetDB.category_product (category_id, product_id) VALUES (:cat_id, :prod_id)");

    $count = 0;
    foreach ($pivots as $row) {
        $insertPivot->execute([
            ':cat_id' => $row['category_id'],
            ':prod_id' => $row['product_id']
        ]);
        $count++;
    }
    echo "Links created: $count
";

    echo "
Migration Complete! Your 'primefix_db' now has the products structure.
";

} catch (PDOException $e) {
    echo "Migration Failed: " . $e->getMessage() . "
";
}
