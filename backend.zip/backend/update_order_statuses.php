<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

try {
    $db = (new Database())->getConnection();
    $db->exec("ALTER TABLE orders MODIFY COLUMN status ENUM('pending', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled') DEFAULT 'pending'");
    echo "Order statuses updated successfully!
";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "
";
}
