<?php
require 'vendor/autoload.php';
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check DB
    $stmt = $pdo->query("SHOW DATABASES LIKE 'prime_fix_new'");
    if (!$stmt->fetch()) {
        echo "Database 'prime_fix_new' does not exist.
";
        exit;
    }

    echo "Found 'prime_fix_new'. Analyzing schema...
";
    $pdo->exec("USE prime_fix_new");

    // Get Tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tables as $table) {
        // Filter for relevant tables only
        if (str_contains($table, 'product') || str_contains($table, 'category') || str_contains($table, 'brand')) {
            echo "
--- Table: $table ---
";
            $columns = $pdo->query("DESCRIBE $table")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($columns as $col) {
                echo "  " . $col['Field'] . " (" . $col['Type'] . ")
";
            }
        }
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "
";
}
