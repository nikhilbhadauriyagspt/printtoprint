<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class DashboardController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function stats() {
        try {
            $stats = [];

            // Total Products
            $stats['products'] = $this->db->query("SELECT COUNT(*) FROM products")->fetchColumn();

            // Total Brands
            $stats['brands'] = $this->db->query("SELECT COUNT(*) FROM brands")->fetchColumn();

            // Total Users
            $stats['users'] = $this->db->query("SELECT COUNT(*) FROM users")->fetchColumn();

            // Low Stock Products
            $stats['low_stock'] = $this->db->query("SELECT COUNT(*) FROM products WHERE quantity < 5")->fetchColumn();

            return ["status" => "success", "data" => $stats];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}
