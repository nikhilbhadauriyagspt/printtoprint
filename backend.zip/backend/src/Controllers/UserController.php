<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class UserController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index() {
        try {
            $stmt = $this->db->prepare("SELECT id, name, email, phone, address, created_at FROM users ORDER BY created_at DESC");
            $stmt->execute();
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return ["status" => "success", "data" => $users];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => "Database error: " . $e->getMessage()];
        }
    }

    public function delete($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM users WHERE id = :id");
            $stmt->bindParam(':id', $id);
            if ($stmt->execute()) {
                return ["status" => "success", "message" => "User deleted successfully"];
            }
            return ["status" => "error", "message" => "Failed to delete user"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => "Database error: " . $e->getMessage()];
        }
    }

    public function update($id, $data) {
        try {
            $fields = [];
            $params = [':id' => $id];

            if (isset($data['name'])) {
                $fields[] = "name = :name";
                $params[':name'] = $data['name'];
            }
            if (isset($data['phone'])) {
                $fields[] = "phone = :phone";
                $params[':phone'] = $data['phone'];
            }
            if (isset($data['address'])) {
                $fields[] = "address = :address";
                $params[':address'] = $data['address'];
            }
            if (!empty($data['password'])) {
                $fields[] = "password = :password";
                $params[':password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }

            if (empty($fields)) {
                return ["status" => "error", "message" => "No fields to update"];
            }

            $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            if ($stmt->execute($params)) {
                // Fetch updated user data
                $stmt = $this->db->prepare("SELECT id, name, email, phone, address, role FROM users WHERE id = ?");
                $stmt->execute([$id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                return ["status" => "success", "message" => "Profile updated successfully", "data" => $user];
            }
            return ["status" => "error", "message" => "Failed to update profile"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => "Database error: " . $e->getMessage()];
        }
    }
}