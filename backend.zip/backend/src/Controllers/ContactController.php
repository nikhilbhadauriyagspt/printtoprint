<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class ContactController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function store($data) {
        if (empty($data['name']) || empty($data['email']) || empty($data['message'])) {
            return ["status" => "error", "message" => "Name, Email and Message are required"];
        }

        try {
            $sql = "INSERT INTO contacts (name, email, phone, subject, message) 
                    VALUES (:name, :email, :phone, :subject, :message)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':name' => $data['name'],
                ':email' => $data['email'],
                ':phone' => $data['phone'] ?? null,
                ':subject' => $data['subject'] ?? 'General Inquiry',
                ':message' => $data['message']
            ]);

            return ["status" => "success", "message" => "Message sent successfully! We will get back to you soon."];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function index() {
        try {
            $stmt = $this->db->query("SELECT * FROM contacts ORDER BY created_at DESC");
            $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return ["status" => "success", "data" => $contacts];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function updateStatus($id, $status) {
        try {
            $stmt = $this->db->prepare("UPDATE contacts SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ["status" => "success", "message" => "Status updated"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}