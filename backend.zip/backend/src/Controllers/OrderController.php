<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class OrderController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index($params) {
        try {
            $userId = $params['user_id'] ?? null;
            $email = $params['email'] ?? null;

            if (!$userId && !$email) {
                return ["status" => "error", "message" => "Authentication required"];
            }

            $sql = "SELECT * FROM orders WHERE ";
            $queryParams = [];
            if ($userId) {
                $sql .= "user_id = :user_id";
                $queryParams[':user_id'] = $userId;
            } else {
                $sql .= "guest_email = :email";
                $queryParams[':email'] = $email;
            }
            $sql .= " ORDER BY created_at DESC";

            $stmt = $this->db->prepare($sql);
            $stmt->execute($queryParams);
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch items for each order
            foreach ($orders as &$order) {
                $itemStmt = $this->db->prepare("SELECT * FROM order_items WHERE order_id = ?");
                $itemStmt->execute([$order['id']]);
                $order['items'] = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
            }

            return ["status" => "success", "data" => $orders];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function all() {
        try {
            $stmt = $this->db->query("SELECT * FROM orders ORDER BY created_at DESC");
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($orders as &$order) {
                $itemStmt = $this->db->prepare("SELECT * FROM order_items WHERE order_id = ?");
                $itemStmt->execute([$order['id']]);
                $order['items'] = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
            }

            return ["status" => "success", "data" => $orders];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function updateStatus($id, $status) {
        try {
            $stmt = $this->db->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            return ["status" => "success", "message" => "Order status updated successfully"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function store($data) {
        if (empty($data['email']) || empty($data['items'])) {
            return ["status" => "error", "message" => "Missing required information"];
        }

        try {
            $this->db->beginTransaction();

            $sql = "INSERT INTO orders (user_id, guest_email, first_name, last_name, address, city, zip_code, phone, total_amount, payment_method, payment_details) 
                    VALUES (:user_id, :email, :first_name, :last_name, :address, :city, :zip_code, :phone, :total, :payment_method, :payment_details)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':user_id' => $data['user_id'] ?? null,
                ':email' => $data['email'],
                ':first_name' => $data['firstName'],
                ':last_name' => $data['lastName'],
                ':address' => $data['address'],
                ':city' => $data['city'],
                ':zip_code' => $data['zipCode'],
                ':phone' => $data['phone'],
                ':total' => $data['total'],
                ':payment_method' => $data['paymentMethod'],
                ':payment_details' => isset($data['payment_details']) ? json_encode($data['payment_details']) : null
            ]);

            $orderId = $this->db->lastInsertId();

            $itemSql = "INSERT INTO order_items (order_id, product_id, product_name, quantity, price) 
                        VALUES (:order_id, :product_id, :name, :quantity, :price)";
            $itemStmt = $this->db->prepare($itemSql);

            foreach ($data['items'] as $item) {
                $itemStmt->execute([
                    ':order_id' => $orderId,
                    ':product_id' => $item['id'],
                    ':name' => $item['name'],
                    ':quantity' => $item['quantity'],
                    ':price' => $item['price']
                ]);
            }

            $this->db->commit();
            return ["status" => "success", "message" => "Order placed successfully", "order_id" => $orderId];

        } catch (\Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}