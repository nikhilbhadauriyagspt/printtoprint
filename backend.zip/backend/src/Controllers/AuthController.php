<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class AuthController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function login($data) {
        $type = $data['type'] ?? 'user';
        $identifier = $data['identifier'] ?? '';
        $password = $data['password'] ?? '';

        if (empty($identifier) || empty($password)) {
            return ["status" => "error", "message" => "Email/Username and Password are required"];
        }

        $table = ($type === 'admin') ? 'admins' : 'users';
        $column = ($type === 'admin') ? 'username' : 'email';

        try {
            $stmt = $this->db->prepare("SELECT * FROM $table WHERE $column = :id");
            $stmt->bindParam(':id', $identifier);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                return ["status" => "error", "message" => "User not found with this email"];
            }

            if (password_verify($password, $user['password'])) {
                unset($user['password']);
                return [
                    "status" => "success", 
                    "message" => "Login successful",
                    "data" => $user,
                    "role" => $type
                ];
            }

            return ["status" => "error", "message" => "Incorrect password"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => "Database error: " . $e->getMessage()];
        }
    }

    public function register($data) {
        $name = trim($data['name'] ?? '');
        $email = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';
        $phone = trim($data['phone'] ?? '');

        if (empty($name) || empty($email) || empty($password)) {
            return ["status" => "error", "message" => "Name, Email and Password are required"];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ["status" => "error", "message" => "Invalid email format"];
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            // Check if email already exists
            $checkStmt = $this->db->prepare("SELECT id FROM users WHERE email = :email");
            $checkStmt->execute([':email' => $email]);
            if ($checkStmt->fetch()) {
                return ["status" => "error", "message" => "Email is already registered. Please login."];
            }

            $stmt = $this->db->prepare("INSERT INTO users (name, email, password, phone) VALUES (:name, :email, :password, :phone)");
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':password' => $hashedPassword,
                ':phone' => $phone
            ]);

            return ["status" => "success", "message" => "Registration successful! You can now login."];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => "Registration failed: " . $e->getMessage()];
        }
    }
}