<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class ProductController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index($params = []) {
        $limit = isset($params['limit']) ? (int)$params['limit'] : 20;
        $page = isset($params['page']) ? (int)$params['page'] : 1;
        $offset = ($page - 1) * $limit;

        $category = $params['category'] ?? null;
        $brand = $params['brand'] ?? null;
        $minPrice = $params['min_price'] ?? null;
        $maxPrice = $params['max_price'] ?? null;
        $sort = $params['sort'] ?? 'newest';
        $search = $params['search'] ?? null;

        try {
            $where = ["1=1"];
            $queryParams = [];

            if ($category) {
                // Handle nested categories
                $where[] = "p.id IN (SELECT product_id FROM category_product WHERE category_id IN (
                    SELECT id FROM categories WHERE slug = :cat OR parent_id IN (SELECT id FROM categories WHERE slug = :cat)
                ))";
                $queryParams[':cat'] = $category;
            }

            if ($brand) {
                $where[] = "b.name = :brand";
                $queryParams[':brand'] = $brand;
            }

            if ($minPrice) {
                $where[] = "p.price >= :minPrice";
                $queryParams[':minPrice'] = $minPrice;
            }

            if ($maxPrice) {
                $where[] = "p.price <= :maxPrice";
                $queryParams[':maxPrice'] = $maxPrice;
            }

            if ($search) {
                $where[] = "(p.name LIKE :search OR p.description LIKE :search)";
                $queryParams[':search'] = "%$search%";
            }

            $whereSql = implode(" AND ", $where);

            // Sorting logic
            $orderBy = "p.created_at DESC";
            if ($sort === 'price_low') $orderBy = "p.price ASC";
            if ($sort === 'price_high') $orderBy = "p.price DESC";
            if ($sort === 'oldest') $orderBy = "p.created_at ASC";
            if ($sort === 'name_asc') $orderBy = "p.name ASC";

            // Get Total Count
            $countSql = "SELECT COUNT(DISTINCT p.id) FROM products p LEFT JOIN brands b ON p.brand_id = b.id WHERE $whereSql";
            $countStmt = $this->db->prepare($countSql);
            foreach ($queryParams as $key => $val) $countStmt->bindValue($key, $val);
            $countStmt->execute();
            $total = $countStmt->fetchColumn();

            // Get Products
            $sql = "SELECT DISTINCT p.*, b.name as brand_name 
                    FROM products p 
                    LEFT JOIN brands b ON p.brand_id = b.id 
                    WHERE $whereSql 
                    ORDER BY $orderBy 
                    LIMIT :limit OFFSET :offset";
            
            $stmt = $this->db->prepare($sql);
            foreach ($queryParams as $key => $val) $stmt->bindValue($key, $val);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return [
                "status" => "success",
                "data" => $products,
                "meta" => [
                    "total" => (int)$total,
                    "page" => $page,
                    "limit" => $limit,
                    "last_page" => ceil($total / $limit)
                ]
            ];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function show($id) {
        try {
            $stmt = $this->db->prepare("SELECT p.*, b.name as brand_name FROM products p LEFT JOIN brands b ON p.brand_id = b.id WHERE p.id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$product) return ["status" => "error", "message" => "Product not found"];

            // Get Categories
            $catStmt = $this->db->prepare("SELECT c.name, c.slug FROM categories c JOIN category_product cp ON c.id = cp.category_id WHERE cp.product_id = ?");
            $catStmt->execute([$id]);
            $product['categories'] = $catStmt->fetchAll(PDO::FETCH_ASSOC);

            return ["status" => "success", "data" => $product];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function store($data) {
        if (empty($data['name']) || empty($data['price'])) {
            return ["status" => "error", "message" => "Name and Price are required"];
        }
        try {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
            $sql = "INSERT INTO products (name, slug, description, price, sale_price, quantity, sku, brand_id, status) 
                    VALUES (:name, :slug, :description, :price, :sale_price, :quantity, :sku, :brand_id, :status)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':name' => $data['name'],
                ':slug' => $slug,
                ':description' => $data['description'] ?? '',
                ':price' => $data['price'],
                ':sale_price' => $data['sale_price'] ?? null,
                ':quantity' => $data['quantity'] ?? 0,
                ':sku' => $data['sku'] ?? '',
                ':brand_id' => $data['brand_id'] ?? null,
                ':status' => $data['status'] ?? 'published'
            ]);
            return ["status" => "success", "message" => "Product created successfully", "id" => $this->db->lastInsertId()];
        } catch (\Exception $e) { return ["status" => "error", "message" => $e->getMessage()]; }
    }

    public function update($id, $data) {
        try {
            $fields = []; $params = [':id' => $id];
            foreach (['name', 'description', 'price', 'sale_price', 'quantity', 'sku', 'status', 'brand_id'] as $field) {
                if (isset($data[$field])) { $fields[] = "$field = :$field"; $params[":$field"] = $data[$field]; }
            }
            if (empty($fields)) return ["status" => "error", "message" => "No fields to update"];
            $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return ["status" => "success", "message" => "Product updated successfully"];
        } catch (\Exception $e) { return ["status" => "error", "message" => $e->getMessage()]; }
    }

    public function delete($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM products WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return ["status" => "success", "message" => "Product deleted successfully"];
        } catch (\Exception $e) { return ["status" => "error", "message" => $e->getMessage()]; }
    }
}