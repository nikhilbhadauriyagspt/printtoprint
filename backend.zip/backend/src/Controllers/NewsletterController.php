<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class NewsletterController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function subscribe($data) {
        if (empty($data['email'])) {
            return ["status" => "error", "message" => "Email is required"];
        }

        try {
            // Check if already subscribed
            $check = $this->db->prepare("SELECT id FROM newsletters WHERE email = ?");
            $check->execute([$data['email']]);
            if ($check->fetch()) {
                return ["status" => "error", "message" => "You are already subscribed!"];
            }

            $sql = "INSERT INTO newsletters (email) VALUES (:email)";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([':email' => $data['email']]);

            return ["status" => "success", "message" => "Successfully subscribed to our newsletter!"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function index() {
        try {
            $stmt = $this->db->query("SELECT * FROM newsletters ORDER BY created_at DESC");
            $emails = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return ["status" => "success", "data" => $emails];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}