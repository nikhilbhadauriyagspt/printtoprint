<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class BrandController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function index() {
        try {
            $stmt = $this->db->query("SELECT * FROM brands ORDER BY name ASC");
            return ["status" => "success", "data" => $stmt->fetchAll(PDO::FETCH_ASSOC)];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function store($data) {
        if (empty($data['name'])) {
            return ["status" => "error", "message" => "Brand name is required"];
        }

        try {
            $stmt = $this->db->prepare("INSERT INTO brands (name, website, status) VALUES (:name, :website, :status)");
            $stmt->execute([
                ':name' => $data['name'],
                ':website' => $data['website'] ?? '',
                ':status' => $data['status'] ?? 'published'
            ]);
            return ["status" => "success", "message" => "Brand created successfully"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function delete($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM brands WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return ["status" => "success", "message" => "Brand deleted"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}
