<?php

namespace App\Controllers;

use App\Config\Database;
use PDO;

class CategoryController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    // Get all categories (tree structure or flat)
    public function index() {
        try {
            // Fetch all categories
            $stmt = $this->db->query("SELECT * FROM categories ORDER BY order_column ASC, name ASC");
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Build Tree
            $tree = [];
            $roots = [];
            
            // First pass: Index by ID and identifying roots
            $byId = [];
            foreach ($categories as $cat) {
                $byId[$cat['id']] = $cat;
                $byId[$cat['id']]['children'] = [];
            }

            // Second pass: Assign children to parents
            foreach ($byId as $id => &$cat) {
                if ($cat['parent_id'] == 0 || $cat['parent_id'] == null) {
                    $roots[] = &$cat;
                } else {
                    if (isset($byId[$cat['parent_id']])) {
                        $byId[$cat['parent_id']]['children'][] = &$cat;
                    }
                }
            }

            return ["status" => "success", "data" => $roots];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    // Create Category
    public function store($data) {
        if (empty($data['name'])) {
            return ["status" => "error", "message" => "Category name is required"];
        }

        try {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $data['name'])));
            $parentId = !empty($data['parent_id']) ? $data['parent_id'] : 0;

            $stmt = $this->db->prepare("INSERT INTO categories (name, slug, parent_id, description, status) VALUES (:name, :slug, :parent, :desc, :status)");
            $stmt->execute([
                ':name' => $data['name'],
                ':slug' => $slug,
                ':parent' => $parentId,
                ':desc' => $data['description'] ?? '',
                ':status' => $data['status'] ?? 'published'
            ]);

            return ["status" => "success", "message" => "Category created successfully"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    // Update Category
    public function update($id, $data) {
        try {
            $fields = [];
            $params = [':id' => $id];

            foreach (['name', 'parent_id', 'description', 'status', 'order_column'] as $field) {
                if (isset($data[$field])) {
                    $fields[] = "$field = :$field";
                    $params[":$field"] = $data[$field];
                }
            }

            if (empty($fields)) {
                return ["status" => "error", "message" => "No fields to update"];
            }

            $sql = "UPDATE categories SET " . implode(', ', $fields) . " WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            return ["status" => "success", "message" => "Category updated successfully"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    // Delete Category
    public function delete($id) {
        try {
            // Optional: Check if it has children and prevent delete?
            // For now, we'll let the database FK constraints handle cascading or errors if configured, 
            // or just delete. Ideally, reassign children to 0 or delete them.
            
            $stmt = $this->db->prepare("DELETE FROM categories WHERE id = :id");
            $stmt->execute([':id' => $id]);
            return ["status" => "success", "message" => "Category deleted"];
        } catch (\Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}
