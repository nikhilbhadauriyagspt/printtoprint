<?php
$p=new PDO('mysql:host=localhost;dbname=ecommerce_db','root','');
foreach($p->query('SELECT image_url FROM products LIMIT 5') as $r) {
    echo $r['image_url'] . "
";
}
