<?php
require_once __DIR__ . '/vendor/autoload.php';
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$dbName = $_ENV['DB_NAME'] ?? 'primefix_db';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbName", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Updating users table...
";
    
    // Add phone column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN phone VARCHAR(20) AFTER email");
        echo "Added 'phone' column.
";
    } catch (PDOException $e) {
        echo "Column 'phone' might already exist or error: " . $e->getMessage() . "
";
    }

    // Add address column if it doesn't exist
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN address TEXT AFTER phone");
        echo "Added 'address' column.
";
    } catch (PDOException $e) {
        echo "Column 'address' might already exist or error: " . $e->getMessage() . "
";
    }

    echo "Database update complete!
";

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage() . "
";
}
