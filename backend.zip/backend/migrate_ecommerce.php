<?php
require_once __DIR__ . '/vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->safeLoad();

$host = 'localhost';
$user = 'root';
$pass = '';
$sourceDB = 'ecommerce_db';
$targetDB = 'primefix_db';

try {
    $sourcePdo = new PDO("mysql:host=$host;dbname=$sourceDB", $user, $pass);
    $targetPdo = new PDO("mysql:host=$host;dbname=$targetDB", $user, $pass);
    
    $sourcePdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $targetPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Migration started...
";

    // 1. Ensure "Printers" parent category exists
    $stmt = $targetPdo->prepare("SELECT id FROM categories WHERE name = 'Printers' LIMIT 1");
    $stmt->execute();
    $printerParent = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$printerParent) {
        $stmt = $targetPdo->prepare("INSERT INTO categories (name, slug, parent_id, status) VALUES ('Printers', 'printers', 0, 'published')");
        $stmt->execute();
        $printerParentId = $targetPdo->lastInsertId();
        echo "Created 'Printers' parent category (ID: $printerParentId).
";
    } else {
        $printerParentId = $printerParent['id'];
        echo "Found 'Printers' parent category (ID: $printerParentId).
";
    }

    // 2. Fetch and migrate categories
    $catMapping = [];
    $sourceCats = $sourcePdo->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($sourceCats as $cat) {
        // Check if category exists in target
        $stmt = $targetPdo->prepare("SELECT id FROM categories WHERE name = ? OR slug = ?");
        $stmt->execute([$cat['name'], $cat['slug']]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $catMapping[$cat['id']] = $existing['id'];
            echo "Category '{$cat['name']}' already exists. Mapping to ID: {$existing['id']}.
";
        } else {
            $stmt = $targetPdo->prepare("INSERT INTO categories (name, slug, parent_id, image, status) VALUES (?, ?, ?, ?, 'published')");
            $stmt->execute([$cat['name'], $cat['slug'], $printerParentId, $cat['image']]);
            $newId = $targetPdo->lastInsertId();
            $catMapping[$cat['id']] = $newId;
            echo "Migrated category '{$cat['name']}' (New ID: $newId) under Printers.
";
        }
    }

    // 3. Fetch and migrate products
    $sourceProducts = $sourcePdo->query("SELECT * FROM products")->fetchAll(PDO::FETCH_ASSOC);
    $productCount = 0;

    foreach ($sourceProducts as $p) {
        // Check if product exists (by slug)
        $stmt = $targetPdo->prepare("SELECT id FROM products WHERE slug = ?");
        $stmt->execute([$p['slug']]);
        if ($stmt->fetch()) {
            echo "Skipping existing product: {$p['name']}
";
            continue;
        }

        // Prepare image JSON
        $images = json_encode([$p['image_url']]);

        // Insert product (Description is empty as requested)
        $stmt = $targetPdo->prepare("INSERT INTO products (name, slug, price, quantity, images, status, description) VALUES (?, ?, ?, ?, ?, 'published', '')");
        $stmt->execute([
            $p['name'],
            $p['slug'],
            $p['price'],
            $p['stock'],
            $images
        ]);
        
        $newProductId = $targetPdo->lastInsertId();

        // Map to category
        if (isset($catMapping[$p['category_id']])) {
            $stmt = $targetPdo->prepare("INSERT INTO category_product (category_id, product_id) VALUES (?, ?)");
            $stmt->execute([$catMapping[$p['category_id']], $newProductId]);
        } else {
            // Fallback to Printers parent if category not found
            $stmt = $targetPdo->prepare("INSERT INTO category_product (category_id, product_id) VALUES (?, ?)");
            $stmt->execute([$printerParentId, $newProductId]);
        }

        $productCount++;
        if ($productCount % 10 == 0) echo "Migrated $productCount products...
";
    }

    echo "
Migration completed! Total products migrated: $productCount
";

} catch (PDOException $e) {
    echo "Migration Error: " . $e->getMessage() . "
";
}
