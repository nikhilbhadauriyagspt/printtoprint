<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Config\Database;

try {
    $db = (new Database())->getConnection();
    
    // Create Orders Table
    $db->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        guest_email VARCHAR(191) NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        address TEXT NOT NULL,
        city VARCHAR(100) NOT NULL,
        zip_code VARCHAR(20) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        payment_method ENUM('paypal', 'cod') NOT NULL,
        status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Order Items Table
    $db->exec("CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        product_name VARCHAR(191) NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(15,2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    )");

    echo "Orders tables created successfully!
";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "
";
}
